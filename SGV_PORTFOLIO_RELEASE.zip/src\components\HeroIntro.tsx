import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowDown, FileDown, Mail, Film, Sparkles, Volume2, SkipForward } from 'lucide-react';
import { ProfileData } from '../types';
import { cinematicAudio } from '../lib/audioFX';

interface HeroIntroProps {
  profile: ProfileData;
  onExploreWork: () => void;
  onDownloadResume: () => void;
  onContactClick: () => void;
  autoPlayIntro?: boolean;
}

export const HeroIntro: React.FC<HeroIntroProps> = ({
  profile,
  onExploreWork,
  onDownloadResume,
  onContactClick,
  autoPlayIntro = true
}) => {
  // Phase 0: Pitch Black Screen
  // Phase 1: Letter-by-letter GOKULAVASAN Name Reveal with fiery glow
  // Phase 2: Hero Swagger Walk Animation
  // Phase 3: Transition to Full Cinematic Portfolio Hero
  const [phase, setPhase] = useState<number>(autoPlayIntro ? 0 : 3);
  const [revealedLetters, setRevealedLetters] = useState<number>(0);
  const nameString = profile.name || "GOKULAVASAN";

  useEffect(() => {
    if (!autoPlayIntro) return;

    // Sequence timing
    // Step 0 -> Step 1 after 700ms
    const timer0 = setTimeout(() => {
      setPhase(1);
      cinematicAudio.playBassBoom();
    }, 700);

    return () => clearTimeout(timer0);
  }, [autoPlayIntro]);

  useEffect(() => {
    if (phase === 1) {
      const interval = setInterval(() => {
        setRevealedLetters((prev) => {
          if (prev < nameString.length) {
            return prev + 1;
          } else {
            clearInterval(interval);
            // Move to Phase 2 (Hero Walk) after letters finish
            setTimeout(() => {
              setPhase(2);
              cinematicAudio.playWhoosh();
            }, 900);
            return prev;
          }
        });
      }, 120);

      return () => clearInterval(interval);
    }
  }, [phase, nameString]);

  useEffect(() => {
    if (phase === 2) {
      // Hero walks towards camera for 3.5s then seamless transition to Homepage Hero
      const timer2 = setTimeout(() => {
        setPhase(3);
        cinematicAudio.playBassBoom();
      }, 3400);

      return () => clearTimeout(timer2);
    }
  }, [phase]);

  const skipIntro = () => {
    setPhase(3);
    cinematicAudio.playWhoosh();
  };

  return (
    <section id="hero" className="relative min-h-screen w-full bg-[#050505] overflow-hidden flex items-center justify-center">
      {/* Background Cinematic Gradients and Smoke */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Top Rim Glow */}
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-b from-[#B50016]/30 via-[#FF2020]/15 to-transparent blur-[120px]" />
        
        {/* Bottom Atmospheric Smolder */}
        <div className="absolute -bottom-20 left-1/2 -translate-x-1/2 w-[900px] h-[400px] bg-gradient-to-t from-[#FF5A00]/25 via-[#B50016]/10 to-transparent blur-[140px]" />

        {/* Anamorphic Blue-Orange Film Flare Line */}
        <div className="absolute top-1/2 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#FF5A00]/40 to-transparent opacity-30" />
      </div>

      {/* PHASE 0 & 1 & 2: INTRO SEQUENCE OVERLAY */}
      <AnimatePresence>
        {phase < 3 && (
          <motion.div
            key="intro-screen"
            initial={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-50 bg-[#050505] flex flex-col items-center justify-center overflow-hidden"
          >
            {/* Skip Intro Button */}
            <button
              onClick={skipIntro}
              className="absolute top-6 right-6 z-50 flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-zinc-400 hover:text-white bg-zinc-900/60 border border-zinc-800 px-4 py-2 rounded-full transition-all hover:border-[#FF5A00]"
            >
              <span>Skip Intro</span>
              <SkipForward className="w-3.5 h-3.5 text-[#FF5A00]" />
            </button>

            {/* PHASE 1: Dramatic Letter Reveal */}
            {phase === 1 && (
              <div className="flex flex-col items-center justify-center text-center px-4">
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-xs uppercase tracking-[0.5em] text-[#FF5A00] font-bold mb-6 flex items-center gap-2"
                >
                  <span className="w-8 h-[1px] bg-[#FF2020]" />
                  <span>PRESENTS</span>
                  <span className="w-8 h-[1px] bg-[#FF2020]" />
                </motion.div>

                <h1 className="font-cinematic text-4xl sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-[0.2em] text-white flex justify-center">
                  {nameString.split('').map((letter, idx) => (
                    <motion.span
                      key={idx}
                      initial={{ opacity: 0, y: 20, scale: 0.8 }}
                      animate={
                        idx < revealedLetters
                          ? {
                              opacity: 1,
                              y: 0,
                              scale: 1,
                              textShadow:
                                '0 0 25px #FF2020, 0 0 50px #FF5A00, 0 0 80px rgba(255, 155, 36, 0.8)',
                            }
                          : { opacity: 0 }
                      }
                      transition={{ duration: 0.25 }}
                      className="inline-block bg-gradient-to-b from-white via-[#FF9B24] to-[#FF2020] bg-clip-text text-transparent"
                    >
                      {letter}
                    </motion.span>
                  ))}
                </h1>

                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: revealedLetters >= nameString.length ? 1 : 0 }}
                  transition={{ duration: 0.5 }}
                  className="mt-6 text-sm sm:text-base font-medium tracking-[0.3em] uppercase text-zinc-400"
                >
                  A CINEMATIC VISION
                </motion.p>
              </div>
            )}

            {/* PHASE 2: Hero Mass Walking Entrance */}
            {phase === 2 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.6 }}
                className="relative w-full h-full flex flex-col items-center justify-center overflow-hidden"
              >
                {/* Backlight Silhouette Ray */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-[600px] h-[600px] bg-gradient-to-r from-[#B50016]/40 via-[#FF5A00]/50 to-[#FF9B24]/40 rounded-full blur-[140px] animate-pulse" />
                </div>

                {/* Cinematic Slow Motion Swagger Walking Character */}
                <motion.div
                  initial={{ scale: 0.75, y: 80, opacity: 0 }}
                  animate={{ scale: 1.05, y: 0, opacity: 1 }}
                  transition={{ duration: 3.2, ease: "easeOut" }}
                  className="relative z-10 flex flex-col items-center"
                >
                  {/* Atmospheric Spotlight Shadow */}
                  <div className="relative w-72 sm:w-96 h-96 sm:h-[480px] rounded-2xl overflow-hidden border border-[#FF2020]/40 shadow-[0_0_60px_rgba(255,32,32,0.4)] group">
                    <img
                      src={profile.heroCharacterUrl || profile.avatarUrl}
                      alt="Gokulavasan Cinematic Hero Entrance"
                      className="w-full h-full object-cover object-center filter contrast-125 brightness-90 saturate-110"
                    />

                    {/* Dramatic Red/Orange Lens Flare and Rim Light */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent opacity-80" />
                    <div className="absolute inset-0 bg-gradient-to-r from-[#B50016]/30 via-transparent to-[#FF5A00]/30 mix-blend-color-dodge" />
                    
                    {/* Viewfinder Frame overlay */}
                    <div className="absolute top-4 left-4 text-[10px] font-mono uppercase text-[#FF9B24] tracking-widest flex items-center gap-1.5 bg-black/60 px-2 py-0.5 rounded">
                      <span className="w-2 h-2 rounded-full bg-[#FF2020] animate-ping" />
                      <span>REC [24 FPS]</span>
                    </div>

                    <div className="absolute bottom-4 left-4 right-4 flex justify-between text-[11px] font-mono text-zinc-400 bg-black/70 p-2 rounded backdrop-blur">
                      <span>SHUTTER: 1/48</span>
                      <span className="text-[#FF9B24]">TAMIL CINEMA STYLE</span>
                      <span>ISO 800</span>
                    </div>
                  </div>

                  {/* Dramatic Title Banner Below Character */}
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 1, duration: 0.8 }}
                    className="text-center mt-6"
                  >
                    <h2 className="font-cinematic text-3xl sm:text-5xl font-black tracking-[0.2em] bg-gradient-to-r from-white via-[#FF9B24] to-[#FF2020] bg-clip-text text-transparent">
                      {profile.name}
                    </h2>
                    <p className="text-xs sm:text-sm uppercase font-bold tracking-[0.4em] text-[#FF5A00] mt-1">
                      THE MASS ENTRANCE
                    </p>
                  </motion.div>
                </motion.div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* PHASE 3: MASTER PORTFOLIO HOMEPAGE HERO */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 flex flex-col items-center justify-center text-center">
        {/* Director / Creator Clapperboard Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-zinc-900/80 border border-red-900/60 shadow-glow-red mb-6"
        >
          <Film className="w-4 h-4 text-[#FF2020]" />
          <span className="text-xs uppercase font-bold tracking-[0.25em] text-zinc-200">
            CINEMATIC CREATIVE PORTFOLIO
          </span>
          <Sparkles className="w-3.5 h-3.5 text-[#FF9B24]" />
        </motion.div>

        {/* Master Name Reveal Heading */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.4 }}
          className="font-cinematic text-5xl sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-[0.12em] uppercase text-white leading-tight"
        >
          <span className="block bg-gradient-to-b from-white via-zinc-100 to-[#FF9B24] bg-clip-text text-transparent drop-shadow-[0_10px_20px_rgba(0,0,0,0.9)]">
            {profile.name}
          </span>
        </motion.h1>

        {/* Profession Pillars */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-6 flex flex-wrap items-center justify-center gap-3 sm:gap-4 max-w-4xl"
        >
          {profile.titles.map((title, i) => (
            <React.Fragment key={title}>
              <span className="text-xs sm:text-sm md:text-base font-bold uppercase tracking-[0.2em] text-zinc-300 hover:text-[#FF9B24] transition-colors">
                {title}
              </span>
              {i < profile.titles.length - 1 && (
                <span className="text-[#FF2020] font-black text-xs sm:text-sm">/</span>
              )}
            </React.Fragment>
          ))}
        </motion.div>

        {/* Cinematic Tagline */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.9, delay: 0.8 }}
          className="mt-6 text-lg sm:text-2xl font-light italic tracking-wider text-zinc-300 max-w-2xl font-serif"
        >
          "{profile.tagline}"
        </motion.p>

        {/* Hero Character Preview with Tamil Mass Swagger Card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.9 }}
          className="mt-10 relative group"
        >
          <div className="relative w-48 sm:w-60 h-48 sm:h-60 rounded-full p-1 bg-gradient-to-tr from-[#B50016] via-[#FF5A00] to-[#FF9B24] shadow-glow-orange">
            <div className="w-full h-full rounded-full overflow-hidden bg-black">
              <img
                src={profile.avatarUrl}
                alt={profile.name}
                className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-700"
              />
            </div>
          </div>
          {/* Experience Badge */}
          <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-[#050505] border border-[#FF5A00] px-4 py-1 rounded-full text-[11px] uppercase tracking-wider font-bold text-white shadow-lg whitespace-nowrap">
            <span className="text-[#FF9B24]">1 Year Experience</span> • Koyaka YouTube
          </div>
        </motion.div>

        {/* Primary Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 1.1 }}
          className="mt-12 flex flex-wrap items-center justify-center gap-4 sm:gap-6"
        >
          {/* Explore My Work Button */}
          <button
            onClick={onExploreWork}
            className="group relative px-7 py-3.5 rounded-lg bg-gradient-to-r from-[#B50016] via-[#FF2020] to-[#FF5A00] text-white font-bold text-xs sm:text-sm uppercase tracking-[0.2em] shadow-glow-red hover:shadow-[0_0_40px_rgba(255,32,32,0.6)] active:scale-95 transition-all duration-300 flex items-center gap-3 overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-2">
              <span>EXPLORE MY WORK</span>
              <ArrowDown className="w-4 h-4 group-hover:translate-y-1 transition-transform" />
            </span>
            <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          </button>

          {/* Download Resume Button */}
          <button
            onClick={onDownloadResume}
            className="px-6 py-3.5 rounded-lg bg-zinc-900/90 border border-zinc-700 text-zinc-200 hover:text-white hover:border-[#FF9B24] font-bold text-xs sm:text-sm uppercase tracking-[0.2em] active:scale-95 transition-all duration-300 flex items-center gap-2.5 shadow-lg"
          >
            <FileDown className="w-4 h-4 text-[#FF9B24]" />
            <span>DOWNLOAD RESUME</span>
          </button>

          {/* Contact Me Button */}
          <button
            onClick={onContactClick}
            className="px-6 py-3.5 rounded-lg bg-transparent border border-[#FF2020]/70 text-[#FF9B24] hover:bg-[#FF2020]/15 hover:border-[#FF2020] font-bold text-xs sm:text-sm uppercase tracking-[0.2em] active:scale-95 transition-all duration-300 flex items-center gap-2"
          >
            <Mail className="w-4 h-4 text-[#FF2020]" />
            <span>CONTACT ME</span>
          </button>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="mt-16 text-zinc-500 flex flex-col items-center gap-2 cursor-pointer"
          onClick={onExploreWork}
        >
          <span className="text-[10px] uppercase font-bold tracking-[0.3em] text-zinc-400">
            SCROLL DOWN FOR CINEMATIC EXPERIENCE
          </span>
          <ArrowDown className="w-4 h-4 text-[#FF5A00]" />
        </motion.div>
      </div>
    </section>
  );
};
