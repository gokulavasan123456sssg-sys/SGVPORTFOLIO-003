import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, X, Maximize2 } from 'lucide-react';
import { cinematicAudio } from '../lib/audioFX';

interface PhotoItem {
  id: string;
  title: string;
  category: string;
  url: string;
  camera: string;
  lens: string;
  settings: string;
}

export const PhotographyGallery: React.FC = () => {
  const [activePhoto, setActivePhoto] = useState<PhotoItem | null>(null);

  // AUTHENTIC PHOTOGRAPHY FROM GOKULAVASAN'S GOOGLE DRIVE & UPLOADED PORTRAITS
  const photos: PhotoItem[] = [
    {
      id: 'p1',
      title: 'Cinematic Red Rim Portrait - Gokulavasan',
      category: 'Portrait Photography',
      url: '/gokulavasan_profile.jpg',
      camera: 'Sony Alpha 4K',
      lens: '85mm f/1.4 GM',
      settings: '1/250s • f/1.8 • ISO 100'
    },
    {
      id: 'p2',
      title: '📍 Pamban Bridge - Rameshwaram - Dhanushkodi',
      category: 'Architectural & Travel',
      url: 'https://lh3.googleusercontent.com/d/1satVp5qiVEdI2OPBmCnWJieo7BNPMGEO',
      camera: 'Professional Mirrorless',
      lens: '24-70mm f/2.8',
      settings: '1/500s • f/5.6 • ISO 100'
    },
    {
      id: 'p3',
      title: 'Edge of India! 🌅✨ Triple Ocean Confluence',
      category: 'Fine Art Landscape',
      url: 'https://lh3.googleusercontent.com/d/11Zx4SEiI-shpHy1Ws6rO8gFgZ2e4cp98',
      camera: 'Cinema Rig',
      lens: '16-35mm Ultra Wide',
      settings: '1/320s • f/4.0 • ISO 100'
    },
    {
      id: 'p4',
      title: 'Suchindram Thanumalayan Temple - Divine Grandeur',
      category: 'Heritage & Temple Architecture',
      url: 'https://lh3.googleusercontent.com/d/15pd9_kKPBbonvj12NqgQd5QEXII_1KC6',
      camera: 'Low-Light Specialist',
      lens: '35mm Cine Prime',
      settings: '1/160s • f/2.0 • ISO 400'
    },
    {
      id: 'p5',
      title: 'Golden Hour Silhouette 🕊️',
      category: 'Mood & Silhouette',
      url: 'https://lh3.googleusercontent.com/d/1rmZUhXelm0_KXzg6Mk2gbYXjy913yFEs',
      camera: 'Telephoto Prime',
      lens: '70-200mm f/2.8',
      settings: '1/1000s • f/4.0 • ISO 100'
    },
    {
      id: 'p6',
      title: "Asia's Largest Wooden Palace - Padmanabhapuram 🪵✨",
      category: 'Heritage Stills',
      url: 'https://lh3.googleusercontent.com/d/1vdrg_9nSavvBtcdQmswy_cZggmtE4mbL',
      camera: 'Studio High-Res',
      lens: '50mm f/1.4',
      settings: '1/125s • f/2.8 • ISO 200'
    },
    {
      id: 'p7',
      title: 'Where The Oceans Meet - Vivekananda Rock Memorial 🌊✨',
      category: 'Travel Documentary',
      url: 'https://lh3.googleusercontent.com/d/1Lcwhfc8_7Ul7Ar86AZn_Wp_l_sEzbM_5',
      camera: 'Landscape 4K',
      lens: '24mm f/1.4 GM',
      settings: '1/640s • f/5.6 • ISO 100'
    },
    {
      id: 'p8',
      title: 'The Art of Letting Go 🕊️ Minimalist Sky',
      category: 'Minimalist Stills',
      url: 'https://lh3.googleusercontent.com/d/11wgawAkYVxAshOpOijgoTvZVjmunnqlC',
      camera: 'Fine-Art Mirrorless',
      lens: '85mm f/1.8',
      settings: '1/1250s • f/2.8 • ISO 100'
    }
  ];

  const handleOpenPhoto = (photo: PhotoItem) => {
    cinematicAudio.playCameraClick();
    setActivePhoto(photo);
  };

  return (
    <section id="photography" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Camera className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>07. STILL FRAMES & LIGHTROOM</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-cinematic text-3xl sm:text-5xl font-black uppercase tracking-[0.1em] text-white"
          >
            PHOTOGRAPHY & RETOUCHING
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-[#FF9B24] uppercase"
          >
            FROZEN IN TIME WITH PRECISE LIGHTING, EXPOSURE & HIGH-FREQUENCY RETOUCHING
          </motion.p>
        </div>

        {/* Masonry / Grid Gallery */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {photos.map((photo, idx) => (
            <motion.div
              key={photo.id}
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.08 }}
              onClick={() => handleOpenPhoto(photo)}
              className="group relative rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800/80 hover:border-[#FF2020]/70 cursor-pointer shadow-lg hover:shadow-glow-red transition-all duration-500"
            >
              <div className="relative aspect-[3/4] w-full overflow-hidden bg-black">
                <img
                  src={photo.url}
                  alt={photo.title}
                  className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 filter brightness-95 group-hover:brightness-105"
                  onError={(e) => {
                    // Fallback to local image if drive thumbnail has rate-limiting
                    (e.target as HTMLImageElement).src = '/gokulavasan_profile.jpg';
                  }}
                />

                {/* Dark Vignette Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                {/* Hover Shutter Viewfinder */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="p-3 rounded-full bg-black/70 border border-[#FF5A00] text-[#FF9B24]">
                    <Maximize2 className="w-5 h-5" />
                  </div>
                </div>

                {/* Category Pill */}
                <div className="absolute top-3 left-3 bg-black/80 backdrop-blur px-2.5 py-1 rounded border border-zinc-800 text-[10px] uppercase font-bold text-zinc-300">
                  {photo.category}
                </div>

                {/* Photo Info at bottom */}
                <div className="absolute bottom-3 left-3 right-3 p-3 rounded-xl bg-black/70 backdrop-blur border border-zinc-800/80">
                  <h4 className="font-cinematic text-xs font-bold text-white group-hover:text-[#FF9B24] transition-colors truncate">
                    {photo.title}
                  </h4>
                  <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400 mt-1">
                    <span>{photo.lens}</span>
                    <span className="text-[#FF5A00]">{photo.settings}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* LIGHTBOX MODAL */}
      <AnimatePresence>
        {activePhoto && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6"
            onClick={() => setActivePhoto(null)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="relative max-w-4xl max-h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
                <div className="flex items-center gap-2">
                  <Camera className="w-4 h-4 text-[#FF5A00]" />
                  <span className="font-cinematic text-sm font-bold text-white uppercase tracking-wider truncate max-w-md">
                    {activePhoto.title}
                  </span>
                </div>
                <button
                  onClick={() => setActivePhoto(null)}
                  className="p-1.5 rounded-full bg-zinc-800 text-zinc-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Image */}
              <div className="relative overflow-hidden flex items-center justify-center bg-black p-2">
                <img
                  src={activePhoto.url}
                  alt={activePhoto.title}
                  className="max-h-[70vh] w-auto object-contain rounded-lg"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = '/gokulavasan_profile.jpg';
                  }}
                />
              </div>

              {/* Footer Exif Metadata */}
              <div className="p-4 bg-zinc-900 flex flex-wrap items-center justify-between gap-4 text-xs font-mono text-zinc-400 border-t border-zinc-800">
                <span>CAMERA: <strong className="text-white">{activePhoto.camera}</strong></span>
                <span>LENS: <strong className="text-white">{activePhoto.lens}</strong></span>
                <span>EXIF: <strong className="text-[#FF9B24]">{activePhoto.settings}</strong></span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};
