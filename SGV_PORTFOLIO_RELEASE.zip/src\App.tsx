import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroIntro } from './components/HeroIntro';
import { AboutMe } from './components/AboutMe';
import { SkillsSection } from './components/SkillsSection';
import { SelectedWorks } from './components/SelectedWorks';
import { VideoEditingShowcase } from './components/VideoEditingShowcase';
import { CinematographyShowcase } from './components/CinematographyShowcase';
import { PhotographyGallery } from './components/PhotographyGallery';
import { VFXShowreel } from './components/VFXShowreel';
import { ExperienceEducation } from './components/ExperienceEducation';
import { ResumeSection } from './components/ResumeSection';
import { ContactSection } from './components/ContactSection';
import { CustomCursor } from './components/CustomCursor';
import { CinematicVFXCanvas } from './components/CinematicVFXCanvas';
import { AdminLogin } from './components/admin/AdminLogin';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { dataService } from './lib/dataService';
import { ProfileData, Project, SkillCategory, ExperienceItem, EducationItem } from './types';

export function App() {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [skills, setSkills] = useState<SkillCategory[]>([]);
  const [experience, setExperience] = useState<ExperienceItem[]>([]);
  const [education, setEducation] = useState<EducationItem[]>([]);
  const [loading, setLoading] = useState(true);

  // View state: 'site' | 'admin'
  const [currentView, setCurrentView] = useState<'site' | 'admin'>('site');
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [introKey, setIntroKey] = useState(0);

  useEffect(() => {
    // Check if initial hash is #admin
    if (window.location.hash === '#admin') {
      setCurrentView('admin');
    }

    const handleHashChange = () => {
      if (window.location.hash === '#admin') {
        setCurrentView('admin');
      } else if (currentView === 'admin' && window.location.hash !== '#admin') {
        setCurrentView('site');
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    setIsAdminLoggedIn(dataService.isAdminLoggedIn());
    loadAllPortfolioData();

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const loadAllPortfolioData = async () => {
    setLoading(true);
    const [p, projs, skls, exp, edu] = await Promise.all([
      dataService.getProfile(),
      dataService.getProjects(),
      dataService.getSkills(),
      dataService.getExperience(),
      dataService.getEducation()
    ]);
    setProfile(p);
    setProjects(projs);
    setSkills(skls);
    setExperience(exp);
    setEducation(edu);
    setLoading(false);
  };

  const handleOpenAdmin = () => {
    window.location.hash = '#admin';
    setCurrentView('admin');
  };

  const handleCloseAdmin = () => {
    window.location.hash = '';
    setCurrentView('site');
    loadAllPortfolioData(); // Refresh any updates made in admin
  };

  const handleReplayIntro = () => {
    setIntroKey(prev => prev + 1);
    const heroElem = document.getElementById('hero');
    if (heroElem) heroElem.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollTo = (id: string) => {
    const elem = document.getElementById(id);
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  if (loading || !profile) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center text-white">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-2 border-[#FF2020] border-t-transparent rounded-full animate-spin" />
          <span className="font-cinematic text-sm uppercase tracking-[0.3em] text-[#FF9B24]">
            INITIALIZING GOKULAVASAN CINEMATIC EXPERIENCE...
          </span>
        </div>
      </div>
    );
  }

  // IF IN ADMIN VIEW
  if (currentView === 'admin') {
    if (!isAdminLoggedIn) {
      return (
        <AdminLogin
          onSuccess={() => setIsAdminLoggedIn(true)}
          onExit={handleCloseAdmin}
        />
      );
    }
    return (
      <AdminDashboard
        onLogout={() => setIsAdminLoggedIn(false)}
        onViewSite={handleCloseAdmin}
      />
    );
  }

  // PUBLIC CINEMATIC PORTFOLIO
  return (
    <div className="relative min-h-screen bg-[#050505] text-white selection:bg-[#FF2020] selection:text-white">
      {/* Dynamic Viewfinder Reticle & Glow Cursor */}
      <CustomCursor />

      {/* Atmospheric Embers, Film Grain & Smoke Canvas */}
      <CinematicVFXCanvas />

      {/* Sticky Cinematic Navigation */}
      <Navbar
        onOpenAdmin={handleOpenAdmin}
        onReplayIntro={handleReplayIntro}
      />

      <main className="relative">
        {/* 01 – Cinematic Hero Intro / Walking Swagger */}
        <HeroIntro
          key={introKey}
          profile={profile}
          onExploreWork={() => scrollTo('about')}
          onDownloadResume={() => scrollTo('resume')}
          onContactClick={() => scrollTo('contact')}
          autoPlayIntro={introKey === 0}
        />

        {/* 02 – About Me */}
        <AboutMe profile={profile} />

        {/* 03 – My Skills */}
        <SkillsSection skills={skills} />

        {/* 04 – Selected Works / Projects Gallery */}
        <SelectedWorks projects={projects} />

        {/* 05 – Video Editing Showcase */}
        <VideoEditingShowcase />

        {/* 06 – Cinematography Showcase */}
        <CinematographyShowcase />

        {/* 07 – Photography Gallery */}
        <PhotographyGallery />

        {/* 08 – VFX Showreel & Certification */}
        <VFXShowreel />

        {/* 09 & 10 – Experience & Education */}
        <ExperienceEducation
          experience={experience}
          education={education}
        />

        {/* 11 – Resume Download */}
        <ResumeSection
          profile={profile}
          experience={experience}
          education={education}
        />

        {/* 12 – Contact Section */}
        <ContactSection profile={profile} />
      </main>
    </div>
  );
}

export default App;
