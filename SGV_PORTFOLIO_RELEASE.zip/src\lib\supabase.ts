import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Retrieve keys from environment variables or custom localStorage settings
const envUrl = import.meta.env.VITE_SUPABASE_URL || '';
const envKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const getStoredSupabaseConfig = () => {
  const customUrl = localStorage.getItem('sgv_supabase_url');
  const customKey = localStorage.getItem('sgv_supabase_anon_key');
  return {
    url: customUrl || envUrl,
    anonKey: customKey || envKey,
  };
};

export const createCustomSupabaseClient = (url?: string, key?: string): SupabaseClient | null => {
  const config = getStoredSupabaseConfig();
  const targetUrl = url || config.url;
  const targetKey = key || config.anonKey;

  if (!targetUrl || !targetKey || targetUrl === 'https://your-project.supabase.co') {
    return null;
  }

  try {
    return createClient(targetUrl, targetKey);
  } catch (err) {
    console.warn('Failed to initialize Supabase client:', err);
    return null;
  }
};

export const supabase = createCustomSupabaseClient();
