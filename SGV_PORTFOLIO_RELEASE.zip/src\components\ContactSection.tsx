import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, MessageSquare, Sparkles, CheckCircle2 } from 'lucide-react';
import { ProfileData } from '../types';
import { cinematicAudio } from '../lib/audioFX';

// Dedicated brand icons
const InstagramIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

const YoutubeIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17"/>
    <polygon points="10 15 15 12 10 9 10 15" fill="currentColor"/>
  </svg>
);

const LinkedinIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/>
    <rect width="4" height="12" x="2" y="9"/>
    <circle cx="4" cy="4" r="2"/>
  </svg>
);

interface ContactSectionProps {
  profile: ProfileData;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ profile }) => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    projectType: 'Video Editing',
    message: ''
  });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    cinematicAudio.playBassBoom();
    setSent(true);
    setTimeout(() => {
      setSent(false);
      setFormState({ name: '', email: '', projectType: 'Video Editing', message: '' });
    }, 4000);
  };

  return (
    <section id="contact" className="relative py-28 bg-[#050505] text-white overflow-hidden border-t border-zinc-900">
      {/* Background Cinematic Glows */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-r from-[#B50016]/20 via-[#FF5A00]/15 to-transparent blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-red-900/40 text-xs uppercase font-bold tracking-[0.25em] text-[#FF5A00] mb-4"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#FF2020]" />
            <span>12. INITIATE COLLABORATION</span>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="font-cinematic text-3xl sm:text-5xl lg:text-6xl font-black uppercase tracking-[0.08em] text-white"
          >
            LET'S CREATE SOMETHING CINEMATIC.
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="mt-4 text-sm sm:text-base font-light tracking-widest text-[#FF9B24] uppercase"
          >
            AVAILABLE FOR COMMERCIAL EDITS, CINEMATOGRAPHY, WEDDINGS & VFX
          </motion.p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Contact Direct Action Cards */}
          <div className="lg:col-span-5 flex flex-col gap-5">
            {/* Quick Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* Call */}
              <a
                href={`tel:${profile.phone.replace(/\s+/g, '')}`}
                className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-[#FF2020] text-center group transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-red-950/60 text-[#FF5A00] flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                  <Phone className="w-5 h-5" />
                </div>
                <span className="block text-xs font-bold uppercase tracking-wider text-white">
                  CALL ME
                </span>
                <span className="text-[10px] text-zinc-400">Direct Voice</span>
              </a>

              {/* Email */}
              <a
                href={`mailto:${profile.email}`}
                className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-[#FF5A00] text-center group transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-red-950/60 text-[#FF9B24] flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                  <Mail className="w-5 h-5" />
                </div>
                <span className="block text-xs font-bold uppercase tracking-wider text-white">
                  EMAIL
                </span>
                <span className="text-[10px] text-zinc-400">Direct Inbox</span>
              </a>

              {/* WhatsApp */}
              <a
                href={profile.whatsapp || `https://wa.me/919344084435`}
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-emerald-500 text-center group transition-all"
              >
                <div className="w-10 h-10 rounded-full bg-emerald-950/60 text-emerald-400 flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <span className="block text-xs font-bold uppercase tracking-wider text-white">
                  WHATSAPP
                </span>
                <span className="text-[10px] text-zinc-400">Instant Chat</span>
              </a>
            </div>

            {/* Direct Contact Details Block */}
            <div className="p-6 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-4">
              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-zinc-900 text-[#FF2020]">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-mono text-zinc-400 block">Phone / Mobile</span>
                  <a href={`tel:${profile.phone}`} className="text-sm sm:text-base font-bold text-white hover:text-[#FF9B24] transition-colors">
                    {profile.phone}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-zinc-900 text-[#FF5A00]">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-mono text-zinc-400 block">Official Email</span>
                  <a href={`mailto:${profile.email}`} className="text-sm font-bold text-white hover:text-[#FF9B24] transition-colors break-all">
                    {profile.email}
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="p-3 rounded-lg bg-zinc-900 text-[#FF9B24]">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-mono text-zinc-400 block">Creative Studio Location</span>
                  <span className="text-sm font-bold text-white">
                    {profile.location}
                  </span>
                </div>
              </div>
            </div>

            {/* Social Media Link Placeholders (Fully editable in admin) */}
            <div className="p-5 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
              <span className="text-xs uppercase font-mono tracking-wider text-zinc-400">
                FOLLOW PRODUCTION:
              </span>
              <div className="flex items-center gap-3">
                {profile.instagram && (
                  <a
                    href={profile.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-lg bg-zinc-900 text-zinc-300 hover:text-[#FF2020] hover:bg-zinc-800 transition-colors"
                    title="Instagram"
                  >
                    <InstagramIcon className="w-4 h-4" />
                  </a>
                )}
                {profile.youtube && (
                  <a
                    href={profile.youtube}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-lg bg-zinc-900 text-zinc-300 hover:text-[#FF2020] hover:bg-zinc-800 transition-colors"
                    title="YouTube"
                  >
                    <YoutubeIcon className="w-4 h-4" />
                  </a>
                )}
                {profile.linkedin && (
                  <a
                    href={profile.linkedin}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2.5 rounded-lg bg-zinc-900 text-zinc-300 hover:text-[#FF5A00] hover:bg-zinc-800 transition-colors"
                    title="LinkedIn"
                  >
                    <LinkedinIcon className="w-4 h-4" />
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Direct Message Form */}
          <div className="lg:col-span-7">
            <form
              onSubmit={handleSubmit}
              className="p-8 rounded-2xl bg-zinc-950 border border-red-950/80 shadow-glow-red flex flex-col gap-5"
            >
              <h3 className="font-cinematic text-xl font-bold uppercase tracking-wider text-white">
                PROJECT INQUIRY
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-mono uppercase text-zinc-400 mb-1.5">
                    Your Name
                  </label>
                  <input
                    type="text"
                    required
                    value={formState.name}
                    onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                    placeholder="e.g. Director Shankar"
                    className="w-full px-4 py-3 rounded-lg bg-zinc-900 border border-zinc-800 focus:border-[#FF2020] focus:outline-none text-white text-sm"
                  />
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-zinc-400 mb-1.5">
                    Your Email
                  </label>
                  <input
                    type="email"
                    required
                    value={formState.email}
                    onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                    placeholder="name@production.com"
                    className="w-full px-4 py-3 rounded-lg bg-zinc-900 border border-zinc-800 focus:border-[#FF2020] focus:outline-none text-white text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1.5">
                  Project Category
                </label>
                <select
                  value={formState.projectType}
                  onChange={(e) => setFormState({ ...formState, projectType: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-zinc-900 border border-zinc-800 focus:border-[#FF2020] focus:outline-none text-white text-sm"
                >
                  <option value="Video Editing">Video Editing & Color Grading</option>
                  <option value="Wedding Films">Cinematic Wedding Film</option>
                  <option value="Cinematography">Cinematography & Camera Direction</option>
                  <option value="Photography">Editorial / Commercial Photography</option>
                  <option value="VFX & 3D">VFX, Compositing & 3D Assets</option>
                  <option value="YouTube Content">YouTube Pacing & Channel Video Production</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1.5">
                  Project Details / Creative Brief
                </label>
                <textarea
                  required
                  rows={4}
                  value={formState.message}
                  onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                  placeholder="Tell me about your film, shoot schedule, or editing requirements..."
                  className="w-full px-4 py-3 rounded-lg bg-zinc-900 border border-zinc-800 focus:border-[#FF2020] focus:outline-none text-white text-sm"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-xl bg-gradient-to-r from-[#B50016] via-[#FF2020] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-[0.2em] shadow-glow-red hover:brightness-110 active:scale-[0.99] transition-all flex items-center justify-center gap-2"
              >
                {sent ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-white" />
                    <span>TRANSMISSION SENT! THANK YOU</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>TRANSMIT CREATIVE BRIEF</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>

        {/* Footer Signature */}
        <div className="mt-24 pt-8 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between text-xs text-zinc-500 gap-4">
          <p>© {new Date().getFullYear()} {profile.name}. All cinematic rights reserved.</p>
          <div className="flex items-center gap-3">
            <span className="font-mono text-[#FF9B24]">TURNING EVERY FRAME INTO A STORY</span>
            <span className="text-zinc-700">|</span>
            <span>CHENNAI, INDIA</span>
          </div>
        </div>
      </div>
    </section>
  );
};
