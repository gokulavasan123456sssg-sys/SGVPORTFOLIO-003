import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Volume2, VolumeX, Shield, Play } from 'lucide-react';
import { cinematicAudio } from '../lib/audioFX';

interface NavbarProps {
  onOpenAdmin: () => void;
  onReplayIntro?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAdmin, onReplayIntro }) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [soundActive, setSoundActive] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      const currentProgress = totalScroll > 0 ? (window.scrollY / totalScroll) * 100 : 0;
      setScrollProgress(currentProgress);
      setScrolled(window.scrollY > 40);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleToggleSound = () => {
    const isNowOn = cinematicAudio.toggleSound();
    setSoundActive(isNowOn);
  };

  const navLinks = [
    { label: 'ABOUT', href: '#about' },
    { label: 'SKILLS', href: '#skills' },
    { label: 'WORKS', href: '#projects' },
    { label: 'EDITING', href: '#editing' },
    { label: 'CINEMATOGRAPHY', href: '#cinematography' },
    { label: 'PHOTOGRAPHY', href: '#photography' },
    { label: 'VFX', href: '#vfx' },
    { label: 'EXPERIENCE', href: '#experience' },
    { label: 'RESUME', href: '#resume' },
    { label: 'CONTACT', href: '#contact' },
  ];

  const handleNavClick = (href: string) => {
    setMobileMenuOpen(false);
    cinematicAudio.playWhoosh();
    const elem = document.querySelector(href);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Scroll Progress Bar */}
      <div 
        className="fixed top-0 left-0 h-[3px] bg-gradient-to-r from-[#B50016] via-[#FF2020] to-[#FF9B24] z-50 transition-all duration-100 ease-out shadow-[0_0_10px_#FF2020]"
        style={{ width: `${scrollProgress}%` }}
      />

      <header
        className={`fixed top-0 left-0 w-full z-40 transition-all duration-500 ${
          scrolled
            ? 'bg-[#050505]/90 backdrop-blur-md border-b border-red-950/40 py-3 shadow-[0_10px_30px_rgba(0,0,0,0.8)]'
            : 'bg-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo / Brand Signature */}
          <a
            href="#hero"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('#hero');
            }}
            className="group flex items-center gap-2"
          >
            <span className="font-cinematic text-xl sm:text-2xl font-black tracking-[0.25em] bg-gradient-to-r from-white via-[#FF9B24] to-[#FF2020] bg-clip-text text-transparent group-hover:scale-105 transition-transform duration-300">
              GOKULAVASAN
            </span>
            <span className="hidden sm:inline-block text-[10px] uppercase font-bold tracking-widest text-[#FF5A00] border border-[#FF2020]/40 px-1.5 py-0.5 rounded">
              FILMMAKER
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <button
                key={link.label}
                onClick={() => handleNavClick(link.href)}
                className="text-xs uppercase font-semibold tracking-widest text-zinc-400 hover:text-[#FF9B24] transition-colors duration-200 relative py-1 group"
              >
                {link.label}
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-[#FF2020] to-[#FF9B24] group-hover:w-full transition-all duration-300" />
              </button>
            ))}
          </nav>

          {/* Actions & Utilities */}
          <div className="flex items-center gap-3">
            {/* Replay Intro Button */}
            {onReplayIntro && (
              <button
                onClick={onReplayIntro}
                title="Replay Cinematic Intro"
                className="hidden sm:flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded bg-zinc-900/80 border border-zinc-800 text-zinc-300 hover:text-white hover:border-[#FF5A00]/50 transition-all"
              >
                <Play className="w-3 h-3 text-[#FF5A00]" />
                <span className="text-[11px] uppercase tracking-wider">Intro</span>
              </button>
            )}

            {/* Audio Toggle */}
            <button
              onClick={handleToggleSound}
              title={soundActive ? 'Mute Cinematic Audio' : 'Enable Cinematic Audio'}
              className={`p-2 rounded-full border transition-all duration-300 ${
                soundActive
                  ? 'border-[#FF2020] bg-[#FF2020]/10 text-[#FF9B24] shadow-[0_0_12px_rgba(255,32,32,0.4)]'
                  : 'border-zinc-800 bg-zinc-900/60 text-zinc-400 hover:text-white hover:border-zinc-700'
              }`}
            >
              {soundActive ? <Volume2 className="w-4 h-4 animate-pulse" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Admin Portal Button */}
            <button
              onClick={onOpenAdmin}
              title="Open Admin Portal"
              className="flex items-center gap-1.5 text-xs uppercase font-bold tracking-wider px-3 py-1.5 rounded bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white hover:brightness-110 active:scale-95 transition-all shadow-[0_0_15px_rgba(255,32,32,0.3)]"
            >
              <Shield className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Admin</span>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded text-zinc-300 hover:text-white hover:bg-zinc-800/60 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-30 bg-[#050505]/95 backdrop-blur-xl pt-24 px-6 flex flex-col justify-between pb-10 lg:hidden"
          >
            <div className="flex flex-col gap-4">
              <span className="text-xs uppercase tracking-[0.3em] text-[#FF5A00] font-bold border-b border-zinc-800 pb-2">
                Cinematic Navigation
              </span>
              {navLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => handleNavClick(link.href)}
                  className="text-left font-cinematic text-lg uppercase tracking-wider text-zinc-200 hover:text-[#FF9B24] transition-colors py-1.5"
                >
                  {link.label}
                </button>
              ))}
            </div>

            <div className="pt-6 border-t border-zinc-800 flex flex-col gap-3">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenAdmin();
                }}
                className="w-full flex items-center justify-center gap-2 py-3 rounded bg-gradient-to-r from-[#B50016] to-[#FF5A00] font-bold text-sm tracking-wider text-white shadow-glow-red"
              >
                <Shield className="w-4 h-4" />
                ENTER ADMIN DASHBOARD
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};
