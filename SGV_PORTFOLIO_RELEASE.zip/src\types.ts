export type ProjectCategory = 
  | 'All'
  | 'Wedding Films'
  | 'Video Editing'
  | 'Cinematography'
  | 'Photography'
  | 'VFX & Showreels'
  | 'Creative Projects';

export interface Project {
  id: string;
  title: string;
  category: ProjectCategory;
  description: string;
  thumbnail: string;
  videoUrl?: string; // YouTube, Vimeo, Drive, or direct mp4/webm
  images?: string[];
  date: string;
  client?: string;
  role?: string;
  featured?: boolean;
  order?: number;
}

export interface SkillCategory {
  title: string;
  icon: string;
  description: string;
  skills: string[];
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  duration: string;
  description: string[];
  highlights?: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  institution: string;
  score?: string;
  year?: string;
  details?: string;
}

export interface ProfileData {
  name: string;
  tagline: string;
  titles: string[];
  aboutHeading: string;
  aboutText: string[];
  avatarUrl: string;
  heroCharacterUrl?: string;
  experienceYears: string;
  currentWork: string;
  email: string;
  phone: string;
  location: string;
  whatsapp: string;
  instagram: string;
  youtube: string;
  linkedin?: string;
  resumeUrl: string;
  resumeFileName: string;
}
