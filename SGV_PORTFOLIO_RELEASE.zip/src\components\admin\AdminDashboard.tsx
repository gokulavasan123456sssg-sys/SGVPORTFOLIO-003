import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LayoutDashboard,
  Film,
  Image as ImageIcon,
  Video,
  Tags,
  User,
  Sparkles,
  FileText,
  Mail,
  Settings,
  LogOut,
  Plus,
  Trash2,
  Edit2,
  Save,
  Check,
  Upload,
  ExternalLink,
  Copy,
  Database,
  ArrowLeft
} from 'lucide-react';
import { Project, ProfileData, SkillCategory, ProjectCategory } from '../../types';
import { dataService } from '../../lib/dataService';
import { SUPABASE_SQL_SCHEMA } from '../../lib/supabaseSchema';
import { cinematicAudio } from '../../lib/audioFX';

interface AdminDashboardProps {
  onLogout: () => void;
  onViewSite: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLogout, onViewSite }) => {
  const [activeTab, setActiveTab] = useState<
    'Overview' | 'Projects' | 'Images' | 'Videos' | 'Categories' | 'Profile' | 'Skills' | 'Resume' | 'Contact' | 'Settings'
  >('Overview');

  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [skills, setSkills] = useState<SkillCategory[]>([]);
  const [loading, setLoading] = useState(true);
  const [saveMessage, setSaveMessage] = useState('');

  // Editing Project State
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  // Supabase Custom Config State
  const [customSupabaseUrl, setCustomSupabaseUrl] = useState(
    localStorage.getItem('sgv_supabase_url') || ''
  );
  const [customSupabaseKey, setCustomSupabaseKey] = useState(
    localStorage.getItem('sgv_supabase_anon_key') || ''
  );
  const [copiedSchema, setCopiedSchema] = useState(false);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    setLoading(true);
    const [prof, projs, skls] = await Promise.all([
      dataService.getProfile(),
      dataService.getProjects(),
      dataService.getSkills()
    ]);
    setProfile(prof);
    setProjects(projs);
    setSkills(skls);
    setLoading(false);
  };

  const showNotification = (msg: string) => {
    setSaveMessage(msg);
    cinematicAudio.playWhoosh();
    setTimeout(() => setSaveMessage(''), 3500);
  };

  // PROJECT ACTIONS
  const handleSaveProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProject) return;

    if (isCreatingNew) {
      await dataService.addProject(editingProject);
      showNotification('New project added successfully!');
    } else {
      await dataService.updateProject(editingProject);
      showNotification('Project updated successfully!');
    }

    setEditingProject(null);
    setIsCreatingNew(false);
    loadAllData();
  };

  const handleDeleteProject = async (id: string) => {
    if (confirm('Are you sure you want to delete this project?')) {
      await dataService.deleteProject(id);
      showNotification('Project deleted.');
      loadAllData();
    }
  };

  const handleFileUpload = async (file: File, targetField: 'thumbnail' | 'avatar' | 'character') => {
    showNotification('Uploading file...');
    try {
      const publicUrl = await dataService.uploadFile(file);
      if (targetField === 'thumbnail' && editingProject) {
        setEditingProject({ ...editingProject, thumbnail: publicUrl });
      } else if (targetField === 'avatar' && profile) {
        setProfile({ ...profile, avatarUrl: publicUrl });
      } else if (targetField === 'character' && profile) {
        setProfile({ ...profile, heroCharacterUrl: publicUrl });
      }
      showNotification('File uploaded & preview set!');
    } catch (err) {
      alert('Upload failed: ' + err);
    }
  };

  // PROFILE ACTIONS
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile) return;
    await dataService.updateProfile(profile);
    showNotification('Profile details updated successfully!');
  };

  // SAVE SUPABASE SETTINGS
  const handleSaveSupabaseConfig = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('sgv_supabase_url', customSupabaseUrl);
    localStorage.setItem('sgv_supabase_anon_key', customSupabaseKey);
    showNotification('Supabase settings saved! Refreshing connection...');
    setTimeout(() => window.location.reload(), 1000);
  };

  const handleCopySchema = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopiedSchema(true);
    setTimeout(() => setCopiedSchema(false), 2500);
  };

  if (loading || !profile) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center text-white font-cinematic">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-[#FF2020] border-t-transparent rounded-full animate-spin" />
          <span className="tracking-widest text-xs uppercase text-[#FF9B24]">LOADING CONTROL ROOM...</span>
        </div>
      </div>
    );
  }

  const navMenuItems = [
    { id: 'Overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'Projects', label: 'Projects', icon: Film },
    { id: 'Images', label: 'Images & Photos', icon: ImageIcon },
    { id: 'Videos', label: 'Videos & Showreels', icon: Video },
    { id: 'Categories', label: 'Categories', icon: Tags },
    { id: 'Profile', label: 'Profile & About', icon: User },
    { id: 'Skills', label: 'Skills', icon: Sparkles },
    { id: 'Resume', label: 'Resume', icon: FileText },
    { id: 'Contact', label: 'Contact Details', icon: Mail },
    { id: 'Settings', label: 'Supabase Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#050505] text-white flex flex-col md:flex-row">
      {/* Toast Notification */}
      {saveMessage && (
        <div className="fixed top-5 right-5 z-50 px-4 py-3 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white text-xs font-bold uppercase tracking-wider shadow-glow-red flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{saveMessage}</span>
        </div>
      )}

      {/* SIDEBAR NAVIGATION */}
      <aside className="w-full md:w-64 bg-zinc-950 border-r border-zinc-900 flex flex-col justify-between shrink-0">
        <div>
          {/* Admin Header */}
          <div className="p-6 border-b border-zinc-900 flex items-center justify-between">
            <div>
              <span className="font-cinematic text-lg font-black tracking-widest bg-gradient-to-r from-white to-[#FF9B24] bg-clip-text text-transparent">
                SGV ADMIN
              </span>
              <span className="block text-[10px] font-mono text-[#FF5A00] uppercase tracking-wider">
                Cinematic Control Room
              </span>
            </div>
            <button
              onClick={onViewSite}
              title="Return to Website"
              className="p-2 rounded bg-zinc-900 text-zinc-400 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="p-4 space-y-1">
            {navMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id as typeof activeTab);
                    cinematicAudio.playWhoosh();
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs uppercase font-bold tracking-wider transition-all ${
                    isActive
                      ? 'bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white shadow-glow-red'
                      : 'text-zinc-400 hover:text-white hover:bg-zinc-900/60'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Sidebar Footer */}
        <div className="p-4 border-t border-zinc-900 flex flex-col gap-2">
          <button
            onClick={onViewSite}
            className="w-full py-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs uppercase font-bold text-zinc-300 hover:text-white flex items-center justify-center gap-2"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[#FF9B24]" />
            <span>View Live Site</span>
          </button>

          <button
            onClick={() => {
              dataService.logoutAdmin();
              onLogout();
            }}
            className="w-full py-2 rounded-lg text-xs font-mono text-zinc-500 hover:text-red-400 flex items-center justify-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Log Out</span>
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 p-6 sm:p-10 overflow-y-auto max-h-screen">
        {/* TAB 1: OVERVIEW */}
        {activeTab === 'Overview' && (
          <div className="space-y-8">
            <div>
              <h1 className="font-cinematic text-3xl font-black uppercase tracking-wider text-white">
                DASHBOARD OVERVIEW
              </h1>
              <p className="text-xs text-zinc-400 mt-1">
                Manage all aspects of Gokulavasan's cinematic portfolio without editing code.
              </p>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-5 rounded-xl bg-zinc-950 border border-zinc-800">
                <span className="text-xs font-mono text-zinc-400 uppercase">Total Projects</span>
                <div className="text-3xl font-cinematic font-black text-[#FF9B24] mt-2">
                  {projects.length}
                </div>
                <span className="text-[10px] text-zinc-500 mt-1 block">Live in portfolio</span>
              </div>

              <div className="p-5 rounded-xl bg-zinc-950 border border-zinc-800">
                <span className="text-xs font-mono text-zinc-400 uppercase">Skill Categories</span>
                <div className="text-3xl font-cinematic font-black text-[#FF2020] mt-2">
                  {skills.length}
                </div>
                <span className="text-[10px] text-zinc-500 mt-1 block">Editing, Photo, Cinema, VFX</span>
              </div>

              <div className="p-5 rounded-xl bg-zinc-950 border border-zinc-800">
                <span className="text-xs font-mono text-zinc-400 uppercase">Current Production</span>
                <div className="text-base font-cinematic font-bold text-white mt-3 truncate">
                  Koyaka YouTube
                </div>
                <span className="text-[10px] text-[#FF5A00] block">1 Year Duration</span>
              </div>

              <div className="p-5 rounded-xl bg-zinc-950 border border-zinc-800">
                <span className="text-xs font-mono text-zinc-400 uppercase">Database Status</span>
                <div className="flex items-center gap-2 mt-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-sm font-bold text-emerald-400">Dynamic & Active</span>
                </div>
                <span className="text-[10px] text-zinc-500 block mt-1">Local + Supabase ready</span>
              </div>
            </div>

            {/* Quick Action Shortcuts */}
            <div className="p-6 rounded-2xl bg-gradient-to-r from-red-950/40 via-zinc-950 to-black border border-red-900/60 flex flex-wrap items-center justify-between gap-4">
              <div>
                <h3 className="font-cinematic text-lg font-bold text-white">
                  Add A New Project Or Media
                </h3>
                <p className="text-xs text-zinc-400 mt-1">
                  Upload high-res photos or link YouTube, Drive, and Vimeo video files directly.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingProject({
                    id: '',
                    title: '',
                    category: 'Video Editing',
                    description: '',
                    thumbnail: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80',
                    videoUrl: '',
                    date: new Date().getFullYear().toString(),
                    role: 'Lead Editor & DP',
                    client: ''
                  });
                  setIsCreatingNew(true);
                  setActiveTab('Projects');
                }}
                className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider shadow-glow-red flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Project Now</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: PROJECTS MANAGER */}
        {activeTab === 'Projects' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
                  PROJECT PORTFOLIO MANAGER
                </h1>
                <p className="text-xs text-zinc-400 mt-1">
                  Add, edit, reorder or delete cinematic works, wedding films, and showreels.
                </p>
              </div>

              <button
                onClick={() => {
                  setEditingProject({
                    id: '',
                    title: '',
                    category: 'Video Editing',
                    description: '',
                    thumbnail: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80',
                    videoUrl: '',
                    date: new Date().getFullYear().toString(),
                    role: 'Lead Editor',
                    client: ''
                  });
                  setIsCreatingNew(true);
                }}
                className="px-4 py-2 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider shadow-glow-red flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                <span>Add Project</span>
              </button>
            </div>

            {/* CREATE / EDIT PROJECT MODAL FORM */}
            {editingProject && (
              <form
                onSubmit={handleSaveProject}
                className="p-6 rounded-2xl bg-zinc-900/90 border border-red-900/60 shadow-2xl space-y-4"
              >
                <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
                  <h3 className="font-cinematic text-lg font-bold text-[#FF9B24] uppercase">
                    {isCreatingNew ? 'Create New Project' : `Edit: ${editingProject.title}`}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setEditingProject(null)}
                    className="text-xs text-zinc-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                      Project Title *
                    </label>
                    <input
                      type="text"
                      required
                      value={editingProject.title}
                      onChange={(e) => setEditingProject({ ...editingProject, title: e.target.value })}
                      placeholder="e.g. Royal Wedding Teaser"
                      className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white focus:border-[#FF2020] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                      Category *
                    </label>
                    <select
                      value={editingProject.category}
                      onChange={(e) => setEditingProject({ ...editingProject, category: e.target.value as ProjectCategory })}
                      className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white focus:border-[#FF2020] focus:outline-none"
                    >
                      <option value="Wedding Films">Wedding Films</option>
                      <option value="Video Editing">Video Editing</option>
                      <option value="Cinematography">Cinematography</option>
                      <option value="Photography">Photography</option>
                      <option value="VFX & Showreels">VFX & Showreels</option>
                      <option value="Creative Projects">Creative Projects</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                    Project Description
                  </label>
                  <textarea
                    rows={3}
                    value={editingProject.description}
                    onChange={(e) => setEditingProject({ ...editingProject, description: e.target.value })}
                    placeholder="Details about narrative, editing rhythm, camera equipment..."
                    className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white focus:border-[#FF2020] focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                      Video URL (YouTube, Vimeo, Google Drive, MP4)
                    </label>
                    <input
                      type="text"
                      value={editingProject.videoUrl || ''}
                      onChange={(e) => setEditingProject({ ...editingProject, videoUrl: e.target.value })}
                      placeholder="https://www.youtube.com/watch?v=..."
                      className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white focus:border-[#FF2020] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                      Thumbnail Image URL / Upload
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={editingProject.thumbnail}
                        onChange={(e) => setEditingProject({ ...editingProject, thumbnail: e.target.value })}
                        placeholder="https://..."
                        className="flex-1 px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white focus:border-[#FF2020] focus:outline-none"
                      />
                      <label className="px-3 py-2 rounded bg-zinc-800 hover:bg-zinc-700 cursor-pointer text-xs flex items-center gap-1 shrink-0">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Upload</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files?.[0]) {
                              handleFileUpload(e.target.files[0], 'thumbnail');
                            }
                          }}
                        />
                      </label>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                      My Role
                    </label>
                    <input
                      type="text"
                      value={editingProject.role || ''}
                      onChange={(e) => setEditingProject({ ...editingProject, role: e.target.value })}
                      placeholder="e.g. Lead Editor & Colorist"
                      className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                      Client / Production
                    </label>
                    <input
                      type="text"
                      value={editingProject.client || ''}
                      onChange={(e) => setEditingProject({ ...editingProject, client: e.target.value })}
                      placeholder="e.g. Koyaka / Private"
                      className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                      Release Date / Year
                    </label>
                    <input
                      type="text"
                      value={editingProject.date || ''}
                      onChange={(e) => setEditingProject({ ...editingProject, date: e.target.value })}
                      placeholder="2024"
                      className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white"
                    />
                  </div>
                </div>

                <div className="pt-3 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setEditingProject(null)}
                    className="px-4 py-2 rounded bg-zinc-800 text-zinc-300 hover:text-white text-xs"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2 rounded bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider shadow-glow-red flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Project</span>
                  </button>
                </div>
              </form>
            )}

            {/* PROJECTS LIST */}
            <div className="space-y-3">
              {projects.map((proj) => (
                <div
                  key={proj.id}
                  className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:border-zinc-700 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <img
                      src={proj.thumbnail}
                      alt={proj.title}
                      className="w-20 h-14 object-cover rounded-lg border border-zinc-800 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-[#FF5A00]">
                          {proj.category}
                        </span>
                        {proj.date && <span className="text-[10px] text-zinc-500 font-mono">{proj.date}</span>}
                      </div>
                      <h4 className="font-cinematic text-sm font-bold text-white mt-1">
                        {proj.title}
                      </h4>
                      <p className="text-xs text-zinc-400 line-clamp-1">
                        {proj.description}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => {
                        setEditingProject(proj);
                        setIsCreatingNew(false);
                      }}
                      className="p-2 rounded bg-zinc-900 hover:bg-zinc-800 text-zinc-300 hover:text-white"
                      title="Edit Project"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteProject(proj.id)}
                      className="p-2 rounded bg-zinc-900 hover:bg-red-950 text-zinc-400 hover:text-red-400"
                      title="Delete Project"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3 & 4: IMAGES & VIDEOS MEDIA MANAGER */}
        {(activeTab === 'Images' || activeTab === 'Videos') && (
          <div className="space-y-6">
            <div>
              <h1 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
                MEDIA ASSET VAULT
              </h1>
              <p className="text-xs text-zinc-400 mt-1">
                Upload new stills, thumbnails or add video links. Instant preview enabled.
              </p>
            </div>

            {/* Quick Upload Drop Area */}
            <div className="p-8 rounded-2xl bg-zinc-950 border-2 border-dashed border-red-950/80 text-center flex flex-col items-center justify-center">
              <div className="w-12 h-12 rounded-full bg-red-950/60 text-[#FF5A00] flex items-center justify-center mb-3">
                <Upload className="w-6 h-6" />
              </div>
              <h4 className="font-cinematic text-sm font-bold text-white uppercase tracking-wider">
                Upload Media To Portfolio
              </h4>
              <p className="text-xs text-zinc-400 max-w-sm mt-1">
                Drag and drop your photography, portraits, project thumbnails or video files.
              </p>

              <label className="mt-4 px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider cursor-pointer shadow-glow-red hover:brightness-110">
                <span>Select Files to Upload</span>
                <input
                  type="file"
                  multiple
                  accept="image/*,video/*"
                  className="hidden"
                  onChange={async (e) => {
                    const files = e.target.files;
                    if (files && files.length > 0) {
                      for (let i = 0; i < files.length; i++) {
                        const url = await dataService.uploadFile(files[i]);
                        showNotification(`Uploaded ${files[i].name}!`);
                      }
                    }
                  }}
                />
              </label>
            </div>

            {/* Existing Project Media Gallery */}
            <div>
              <h3 className="font-cinematic text-sm font-bold text-zinc-300 uppercase tracking-wider mb-4">
                Active Project Media Previews
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {projects.map((p) => (
                  <div key={p.id} className="rounded-xl overflow-hidden bg-zinc-950 border border-zinc-800 p-2 group">
                    <div className="relative aspect-video rounded-lg overflow-hidden bg-black">
                      <img src={p.thumbnail} alt={p.title} className="w-full h-full object-cover" />
                      {p.videoUrl && (
                        <div className="absolute top-2 right-2 bg-black/80 p-1 rounded text-[#FF5A00]">
                          <Video className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                    <div className="mt-2 flex items-center justify-between text-xs">
                      <span className="truncate font-semibold text-zinc-200">{p.title}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: CATEGORIES */}
        {activeTab === 'Categories' && (
          <div className="space-y-6">
            <div>
              <h1 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
                PROJECT CATEGORIES
              </h1>
              <p className="text-xs text-zinc-400 mt-1">
                Portfolio filter categories currently active in the gallery.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { name: 'Wedding Films', count: projects.filter(p => p.category === 'Wedding Films').length },
                { name: 'Video Editing', count: projects.filter(p => p.category === 'Video Editing').length },
                { name: 'Cinematography', count: projects.filter(p => p.category === 'Cinematography').length },
                { name: 'Photography', count: projects.filter(p => p.category === 'Photography').length },
                { name: 'VFX & Showreels', count: projects.filter(p => p.category === 'VFX & Showreels').length },
                { name: 'Creative Projects', count: projects.filter(p => p.category === 'Creative Projects').length },
              ].map((c) => (
                <div key={c.name} className="p-5 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
                  <div>
                    <h4 className="font-cinematic text-base font-bold text-white">{c.name}</h4>
                    <span className="text-xs text-zinc-400">{c.count} assigned projects</span>
                  </div>
                  <span className="text-xs font-mono text-[#FF5A00] font-bold">ACTIVE</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 6: PROFILE & ABOUT EDITOR */}
        {activeTab === 'Profile' && (
          <form onSubmit={handleSaveProfile} className="space-y-6 max-w-4xl">
            <div>
              <h1 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
                PROFILE & IDENTITY
              </h1>
              <p className="text-xs text-zinc-400 mt-1">
                Edit your hero titles, tagline, about section, and character image.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={profile.name}
                  onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                  Tagline
                </label>
                <input
                  type="text"
                  value={profile.tagline}
                  onChange={(e) => setProfile({ ...profile, tagline: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                About Section Heading
              </label>
              <input
                type="text"
                value={profile.aboutHeading}
                onChange={(e) => setProfile({ ...profile, aboutHeading: e.target.value })}
                className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                Avatar / Profile Image URL
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={profile.avatarUrl}
                  onChange={(e) => setProfile({ ...profile, avatarUrl: e.target.value })}
                  className="flex-1 px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
                <label className="px-3 py-2 rounded bg-zinc-800 hover:bg-zinc-700 cursor-pointer text-xs flex items-center gap-1 shrink-0">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files?.[0]) handleFileUpload(e.target.files[0], 'avatar');
                    }}
                  />
                </label>
              </div>
            </div>

            <div>
              <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                Hero Entrance Character URL (Walking Hero Reference)
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={profile.heroCharacterUrl || ''}
                  onChange={(e) => setProfile({ ...profile, heroCharacterUrl: e.target.value })}
                  className="flex-1 px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
                <label className="px-3 py-2 rounded bg-zinc-800 hover:bg-zinc-700 cursor-pointer text-xs flex items-center gap-1 shrink-0">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files?.[0]) handleFileUpload(e.target.files[0], 'character');
                    }}
                  />
                </label>
              </div>
            </div>

            <button
              type="submit"
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider shadow-glow-red flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile Changes</span>
            </button>
          </form>
        )}

        {/* TAB 7: SKILLS */}
        {activeTab === 'Skills' && (
          <div className="space-y-6">
            <div>
              <h1 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
                PROFESSIONAL SKILLS
              </h1>
              <p className="text-xs text-zinc-400 mt-1">
                Industry software and creative skillsets displayed on your portfolio.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {skills.map((cat, cIdx) => (
                <div key={cat.title} className="p-5 rounded-xl bg-zinc-950 border border-zinc-800">
                  <h4 className="font-cinematic text-base font-bold text-[#FF9B24] uppercase mb-3">
                    {cat.title}
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {cat.skills.map((s) => (
                      <span key={s} className="px-3 py-1 rounded bg-zinc-900 border border-zinc-700 text-xs text-zinc-200">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 8: RESUME */}
        {activeTab === 'Resume' && (
          <div className="space-y-6 max-w-3xl">
            <div>
              <h1 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
                RESUME SETTINGS
              </h1>
              <p className="text-xs text-zinc-400 mt-1">
                Configure your downloadable PDF resume file and online viewer.
              </p>
            </div>

            <div className="p-6 rounded-xl bg-zinc-950 border border-zinc-800 space-y-4">
              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                  Resume File Path or Download URL
                </label>
                <input
                  type="text"
                  value={profile.resumeUrl}
                  onChange={(e) => setProfile({ ...profile, resumeUrl: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                  Download Filename
                </label>
                <input
                  type="text"
                  value={profile.resumeFileName}
                  onChange={(e) => setProfile({ ...profile, resumeFileName: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white"
                />
              </div>

              <button
                onClick={handleSaveProfile}
                className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider shadow-glow-red flex items-center gap-2"
              >
                <Save className="w-4 h-4" />
                <span>Save Resume Configuration</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 9: CONTACT */}
        {activeTab === 'Contact' && (
          <form onSubmit={handleSaveProfile} className="space-y-6 max-w-3xl">
            <div>
              <h1 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
                CONTACT DETAILS & SOCIAL MEDIA
              </h1>
              <p className="text-xs text-zinc-400 mt-1">
                Update phone, email, studio location, WhatsApp, Instagram and YouTube links.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">Phone</label>
                <input
                  type="text"
                  value={profile.phone}
                  onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">Email</label>
                <input
                  type="email"
                  value={profile.email}
                  onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">Location</label>
                <input
                  type="text"
                  value={profile.location}
                  onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">WhatsApp URL</label>
                <input
                  type="text"
                  value={profile.whatsapp}
                  onChange={(e) => setProfile({ ...profile, whatsapp: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">Instagram URL</label>
                <input
                  type="text"
                  value={profile.instagram}
                  onChange={(e) => setProfile({ ...profile, instagram: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">YouTube URL</label>
                <input
                  type="text"
                  value={profile.youtube}
                  onChange={(e) => setProfile({ ...profile, youtube: e.target.value })}
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-800 text-sm text-white"
                />
              </div>
            </div>

            <button
              type="submit"
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider shadow-glow-red flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>Save Contact Changes</span>
            </button>
          </form>
        )}

        {/* TAB 10: SUPABASE SETTINGS & SQL SCHEMA */}
        {activeTab === 'Settings' && (
          <div className="space-y-8 max-w-4xl">
            <div>
              <h1 className="font-cinematic text-2xl font-black uppercase tracking-wider text-white">
                SUPABASE CLOUD DATABASE CONFIGURATION
              </h1>
              <p className="text-xs text-zinc-400 mt-1">
                Connect your Supabase project for live multi-device database and cloud storage.
              </p>
            </div>

            {/* Supabase Credentials Form */}
            <form onSubmit={handleSaveSupabaseConfig} className="p-6 rounded-xl bg-zinc-950 border border-zinc-800 space-y-4">
              <h3 className="font-cinematic text-base font-bold text-[#FF9B24] uppercase">
                Connect Your Supabase Project
              </h3>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                  Supabase Project URL
                </label>
                <input
                  type="text"
                  value={customSupabaseUrl}
                  onChange={(e) => setCustomSupabaseUrl(e.target.value)}
                  placeholder="https://xyzcompany.supabase.co"
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-mono uppercase text-zinc-400 mb-1">
                  Supabase Anon Key
                </label>
                <input
                  type="text"
                  value={customSupabaseKey}
                  onChange={(e) => setCustomSupabaseKey(e.target.value)}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                  className="w-full px-3 py-2 rounded bg-black border border-zinc-700 text-sm text-white font-mono"
                />
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-[11px] text-zinc-400">
                  Note: Never enter service_role secret key here. Anon key is public-safe.
                </span>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-lg bg-gradient-to-r from-[#B50016] to-[#FF5A00] text-white font-bold text-xs uppercase tracking-wider shadow-glow-red flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  <span>Save & Connect</span>
                </button>
              </div>
            </form>

            {/* SQL Schema Exporter */}
            <div className="p-6 rounded-xl bg-zinc-950 border border-zinc-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-cinematic text-base font-bold text-white uppercase">
                    Ready-to-Run SQL Schema & Storage Setup
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Paste this directly into your Supabase SQL Editor to set up tables and storage buckets in 5 seconds.
                  </p>
                </div>

                <button
                  onClick={handleCopySchema}
                  className="px-4 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-200 hover:text-white flex items-center gap-1.5"
                >
                  {copiedSchema ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedSchema ? 'Copied SQL!' : 'Copy SQL Script'}</span>
                </button>
              </div>

              <div className="relative">
                <pre className="p-4 rounded-lg bg-black border border-zinc-900 text-xs font-mono text-zinc-300 overflow-x-auto max-h-64">
                  {SUPABASE_SQL_SCHEMA}
                </pre>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
