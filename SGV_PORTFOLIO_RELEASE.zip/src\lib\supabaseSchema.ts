export const SUPABASE_SQL_SCHEMA = `
-- ========================================================
-- GOKULAVASAN CINEMATIC PORTFOLIO - SUPABASE DATABASE SCHEMA
-- ========================================================

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- 1. PROFILE TABLE
create table if not exists public.profile (
  id text primary key default 'main',
  name text not null default 'GOKULAVASAN',
  tagline text default 'Turning Every Frame Into A Story.',
  titles jsonb default '["Video Editor", "Cinematographer", "Photographer", "Visual Effects Artist"]'::jsonb,
  aboutHeading text default 'BEHIND THE CAMERA. BEYOND THE FRAME.',
  aboutText jsonb default '[]'::jsonb,
  avatarUrl text,
  heroCharacterUrl text,
  experienceYears text default '1+ Year',
  currentWork text default 'Koyaka YouTube Channel',
  email text default 'gokulavasan123456sssg@gmail.com',
  phone text default '+91 9344084435',
  location text default 'Chennai, India',
  whatsapp text default 'https://wa.me/919344084435',
  instagram text,
  youtube text,
  linkedin text,
  resumeUrl text default '/Gokulavasan_Resume.pdf',
  resumeFileName text default 'Gokulavasan_Resume.pdf',
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- 2. PROJECTS TABLE
create table if not exists public.projects (
  id text primary key,
  title text not null,
  category text not null,
  description text,
  thumbnail text not null,
  "videoUrl" text,
  images jsonb default '[]'::jsonb,
  date text,
  client text,
  role text,
  featured boolean default false,
  "order" bigint default 0,
  created_at timestamp with time zone default timezone('utc'::text, now())
);

-- 3. SKILLS TABLE
create table if not exists public.skills (
  title text primary key,
  icon text,
  description text,
  skills jsonb not null default '[]'::jsonb
);

-- 4. ROW LEVEL SECURITY (RLS)
alter table public.profile enable row level security;
alter table public.projects enable row level security;
alter table public.skills enable row level security;

-- Public Read Policies
create policy "Allow public read on profile" on public.profile for select using (true);
create policy "Allow public read on projects" on public.projects for select using (true);
create policy "Allow public read on skills" on public.skills for select using (true);

-- Authenticated / Service Role Write Policies
create policy "Allow write access for authenticated users on profile" on public.profile 
  for all using (auth.role() = 'authenticated' or auth.role() = 'anon');

create policy "Allow write access for authenticated users on projects" on public.projects 
  for all using (auth.role() = 'authenticated' or auth.role() = 'anon');

create policy "Allow write access for authenticated users on skills" on public.skills 
  for all using (auth.role() = 'authenticated' or auth.role() = 'anon');

-- 5. STORAGE BUCKET SETUP
-- Create a public bucket called 'portfolio-media'
insert into storage.buckets (id, name, public) 
values ('portfolio-media', 'portfolio-media', true)
on conflict (id) do nothing;

create policy "Public Access to portfolio-media" 
on storage.objects for select using ( bucket_id = 'portfolio-media' );

create policy "Allow upload to portfolio-media" 
on storage.objects for insert with check ( bucket_id = 'portfolio-media' );

create policy "Allow update to portfolio-media" 
on storage.objects for update using ( bucket_id = 'portfolio-media' );

create policy "Allow delete from portfolio-media" 
on storage.objects for delete using ( bucket_id = 'portfolio-media' );
`;
